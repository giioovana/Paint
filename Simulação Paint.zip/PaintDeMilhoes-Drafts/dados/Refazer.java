package dados;

import ponto.FiguraPontos;
import reta.FiguraRetas;
import retangulo.FiguraRetangulo;
import triangulo.FiguraTriangulo;
import pincel.FiguraPinceis;

import dados.ListaLigada;

/**
 * Escreva uma descri��o da classe Refazer aqui.
 * 
 * @author (seu nome) 
 * @version (um n�mero da vers�o ou uma data)
 */
public class Refazer
{   
    //Instancia um novo componente com o conte�do da lista ligada principal
    ListaLigada listaLigada = new ListaLigada();
    
    public void refazerAcao(){
        
    }
}