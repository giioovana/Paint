/**
 * Aplicacao para testar primitivos graficos.
 * 
 * @author Julio Arakaki 
 * @version 20220815
 */

// DELEETEME

import java.io.*;
import java.util.*;

public class App{    
    public static void main(String args[]) {
        // Cria e define dimensao da janela (em pixels)
        new Gui(850, 600); 
    }
}