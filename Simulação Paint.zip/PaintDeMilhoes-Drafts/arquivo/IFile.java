package arquivo;

/**
 * Escreva a descri��o da interface IFile aqui.
 * 
 * @author Pedro Marques Prado, Giovana Akemi, Lucas Kenji Hayashi, Jo�o Pedro do Carmo Ribeiro 
 * @version 1.0 14/08/2023
 */

public interface IFile
{
    public void escrevaArquivo(String drawContent);
    public void leiaArquivo();
}