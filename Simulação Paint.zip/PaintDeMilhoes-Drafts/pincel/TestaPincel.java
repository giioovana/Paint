package pincel;

/**
 * Write a description of class TestaPonto here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class TestaPincel{
    public static void main(String args[]) {
        Pincel r = new Pincel(10, 10, 20, 30);
        System.out.println("Reta: " + r);
    }
}