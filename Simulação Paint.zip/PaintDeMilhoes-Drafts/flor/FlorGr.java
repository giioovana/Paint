package flor;

import java.awt.*;
import java.util.*;
import java.util.Arrays;  

import ponto.PontoGr;
import reta.RetaGr;

/**
 * Implementacao da classe reta grafica.
 *
 * @author Julio Arakaki
 * @version 1.0 - 24/08/2020
 */
public class FlorGr extends Flor{
    // Atributos da reta grafica
    Color corFlor = Color.BLACK;   // cor da reta
    String nomeFlor = ""; // nome da reta
    Color corNomeFlor  = Color.BLACK;
    int espFlor = 1; // espessura da reta

    // Construtores
    /**
     * CirculoGr - Constroi um Circulo grafico
     *
     * @param x1 int. Coordenada x1
     * @param y1 int. Coordenada y1
     * @param x2 int. Coordenada x2
     * @param y2 int. Coordenada y2
     * @param cor Color. Cor da reta
     * @param nome String. Nome da reta
     * @param esp int. Espessura da reta
     */
    public FlorGr(int x, int y, int xc, int yc, Color cor, String nome, int esp){
        super (x, y, xc, yc);
        setCorFlor(cor);
        setNomeFlor(nome);
        setEspFlor(esp);
    }

    /**
     * CirculoGr - Constroi um Circulo grafico
     *
     * @param x1 int. Coordenada x1
     * @param y1 int. Coordenada y1
     * @param x2 int. Coordenada x2
     * @param y2 int. Coordenada y2
     * @param cor Color. Cor da reta
     */
    public FlorGr(int x, int y, int xc, int yc, Color cor){
        super (x, y, xc, yc);
        setCorFlor(cor);
        setNomeFlor("");
    }   

    /**
     * CirculoGr - Constroi um Circulo grafico
     *
     * @param x1 int. Coordenada x1
     * @param y1 int. Coordenada y1
     * @param x2 int. Coordenada x2
     * @param y2 int. Coordenada y2
     * @param cor Color. Cor da reta
     * @param esp int. Espessura da reta
     */
    public FlorGr(int x, int y, int xc, int yc, Color cor, int esp){
        super (x, y, xc, yc);
        setCorFlor(cor);
        setNomeFlor("");
        setEspFlor(esp);
    }   

    /**
     * CirculoGr - Constroi um Circulo grafico
     *
     * @param x1 int. Coordenada x1
     * @param y1 int. Coordenada y1
     * @param x2 int. Coordenada x2
     * @param y2 int. Coordenada y2
     */
    public FlorGr(int x, int y, int xc, int yc){
        super(x, y, xc, yc);
        setCorFlor(Color.black);
        setNomeFlor("");
    }   

    /**
     * CirculoGr - Constroi um Circulo grafico
     *
     * @param p1 PontoGr. Ponto grafico p1 (x1, y1)
     * @param p2 PontoGr. Ponto grafico p2 (x2, y2)
     */
    public FlorGr(PontoGr p3, PontoGr p4){
        super(p3, p4);
        setCorFlor(Color.black);
        setNomeFlor("");
    }    

    /**
     * CirculoGr - Constroi um Circulo grafico
     *
     * @param p1 PontoGr. Ponto grafico p1 (x1, y1)
     * @param p2 PontoGr. Ponto grafico p2 (x2, y2)
     * @param cor Color. Cor da reta
     */
    public FlorGr(PontoGr p3, PontoGr p4, Color cor){
        super(p3, p4);
        setCorFlor(cor);
        setNomeFlor("");
    }    

    /**
     * CirculoGr - Constroi um Circulo grafico
     *
     * @param p1 PontoGr. Ponto grafico p1 (x1, y1)
     * @param p2 PontoGr. Ponto grafico p2 (x2, y2)
     * @param cor Color. Cor da reta
     * @param nome String. Nome da reta
     */
    public FlorGr(PontoGr p3, PontoGr p4, Color cor, String str){
        super(p3, p4);
        setCorFlor(cor);
        setNomeFlor(str);
    }    

    /**
     * Altera a cor da reta.
     *
     * @param cor Color. Cor da reta.
     */
    public void setCorFlor(Color cor) {
        this.corFlor = cor;
    }

    /**
     * Altera o nome da reta.
     *
     * @param str String. Nome da reta.
     */
    public void setNomeFlor(String str) {
        this.nomeFlor = str;
    }

    /**
     * Altera a espessura da reta.
     *
     * @param esp int. Espessura da reta.
     */
    public void setEspFlor(int esp) {
        this.espFlor = esp;
    }

    /**
     * Retorna a espessura da reta.
     *
     * @return int. Espessura da reta.
     */
    public int getEspFlor() {
        return(this.espFlor);
    }

    /**
     * Retorna a cor da reta.
     *
     * @return Color. Cor da reta.
     */
    public Color getCorFlor() {
        return corFlor;
    }

    /**
     * Retorna o nome da reta.
     *
     * @return String. Nome da reta.
     */
    public String getNomeFlor() {
        return nomeFlor;
    }

    /**
     * @return the corNomeReta
     */
    public Color getCorNomeFlor() {
        return corNomeFlor;
    }

    /**
     * @param corNomeReta the corNomeReta to set
     */
    public void setCorNomeFlor(Color corNomeFlor) {
        this.corNomeFlor = corNomeFlor;
    }

    /**
     * Desenha reta grafica utilizando a equacao da reta: y = mx + b
     * Para o caso de x1 > x2
     * @param g Graphics. Classe com os metodos graficos do Java
     */
    public void desenharFlorCompleto(Graphics g){
        // Variaveis auxiliares
        PontoGr ponto, ponto2;
        PontoGr ponto3;

        int theta;
        double x, y, x2, y2, x3, y3, xAnt, yAnt, xProxExt, yProxExt, xAntExt, yAntExt, xProxExt2, yProxExt2, xExt, yExt, difX, difY, xc, yc, r, r2, r3, radianos, radianosInv;
        double angulo, anguloPonto, anguloInv;
        int cont = 0;
        x3 = 0;
        y3 = 0;
        xAntExt = 0;
        yAntExt = 0;

        xc = p3.getX();
        yc = p3.getY();
        x2 = p4.getX();
        y2 = p4.getY();

        System.out.println("VALOR:" + x2 + " " + y2);

        r = Math.sqrt(Math.pow(x2 - xc,2) + Math.pow(y2 - yc,2));
        r3 = Math.sqrt(Math.pow((x2 - xc)*2,2) + Math.pow((y2 - yc)*2,2));

        // Angulo que a figura vai girar
        anguloPonto = Math.toDegrees(Math.atan2(x2 - xc, y2 - yc));
        anguloPonto = anguloPonto + Math.ceil(-anguloPonto / 360) * 360;
        anguloPonto -= 90;
        //anguloInv = anguloPonto;
        anguloPonto *= -1;
        System.out.println("AngPonto:" + anguloPonto);

        // Calcula os 6 pontos internos
        for (angulo = anguloPonto; angulo <= anguloPonto + 300; angulo+=60){
            radianos = Math.toRadians(angulo);
            x = xc + r * Math.cos(radianos);
            y = yc + r * Math.sin(radianos);

            // Define ponto interno grafico
            ponto = new PontoGr((int)x, (int)y, getCorFlor(), getEspFlor() + 10);

            // Desenha ponto interno grafico
            ponto.desenharPonto(g);

            // desenha nome do ponto interno
            g.setColor(getCorNomeFlor());
            g.drawString(getNomeFlor(), (int)getP3().getX() + getEspFlor(), (int)getP3().getY());
            System.out.println("Ponto Interno " + cont + ": " + x + " " + y);

            // CALCULA os 6 Pontos Externos
            x2 = xc + r * Math.cos(radianos+19.9);
            y2 = yc + r * Math.sin(radianos+19.9);
            difX = x - xc;
            difY = y - yc;
            xExt = x2 + difX;
            yExt = y2 + difY;

            System.out.println("Ponto Externo " + cont + ": " + xExt + " " + yExt); 

            // Define ponto grafico externo
            ponto2 = new PontoGr((int)xExt, (int)yExt, getCorFlor(), getEspFlor() + 10);

            // Desenha ponto grafico externo
            ponto2.desenharPonto(g);

            // desenha nome do ponto externo
            g.setColor(getCorNomeFlor());
            g.drawString(getNomeFlor(), (int)getP3().getX() + getEspFlor(), (int)getP3().getY());

            //System.out.println("x2 y2 " + cont + ": " + x2 + " " + y2); 
            //System.out.println("xc yc " + cont + ": " + xc + " " + yc);

            // DESENHA os 6 Triangulos Externos
            xProxExt = x2 + ((xc + r * Math.cos(radianos-29.3333)) - xc);
            yProxExt = y2 + ((yc + r * Math.sin(radianos-29.3333)) - yc);
            
            xProxExt2 = xc + r * Math.cos(radianos-19.9) + ((xc + r * Math.cos(radianos+29.3333)) - xc);
            yProxExt2 = yc + r * Math.sin(radianos-19.9) + ((yc + r * Math.sin(radianos+29.3333)) - yc);
            
            System.out.println("ProxExt2 " + cont + ": " + xProxExt2 + " " + yProxExt2);
            
            RetaGr reta2;

            reta2 = new RetaGr((int)xc,(int)yc,(int)xExt,(int)yExt, getCorFlor(), getNomeFlor(),getEspFlor());
            reta2.verificarReta(g);
            //System.out.println("RETAS DO TRIANG DESENHADO: (" + (int)getP3().getX() + "," + (int)getP3().getY() + ")   (" + (int)x + "," + (int)y);

            reta2 = new RetaGr((int)xExt,(int)yExt,(int)xProxExt,(int)yProxExt, getCorFlor(), getNomeFlor(),getEspFlor());
            reta2.verificarReta(g);
            //System.out.println("RETAS DO TRIANG DESENHADO: (" + (int)x + "," + (int)y + ")   (" + (int)x3 + "," + (int)y3);

            System.out.println("Tri Externo: (" + (int)xc + "," + (int)yc + ")   (" + (int)xExt + "," + (int)yExt + ")   (" + (int)xProxExt + "," + (int)yProxExt + ")");

            
            xAnt = x;
            yAnt = y;
            // DESENHA os 3 Triangulos Internos e 2 Intermediarios
            if (cont % 2 == 0){
                x3 = x;
                y3 = y;
                xAntExt = xExt;
                yAntExt = yExt;
            

                System.out.println("Ponto do triangulo interno " + cont + ": " + x3 + " " + y3);
            
            }
            else{
                // INTERNOS
                RetaGr retaInt;

                retaInt = new RetaGr((int)getP3().getX(),(int)getP3().getY(),(int)x,(int)y, getCorFlor(), getNomeFlor(),getEspFlor());
                retaInt.verificarReta(g);
                //System.out.println("RETAS DO TRIANG DESENHADO: (" + (int)getP3().getX() + "," + (int)getP3().getY() + ")   (" + (int)x + "," + (int)y);

                retaInt = new RetaGr((int)x,(int)y,(int)x3,(int)y3, getCorFlor(), getNomeFlor(),getEspFlor());
                retaInt.verificarReta(g);
                //System.out.println("RETAS DO TRIANG DESENHADO: (" + (int)x + "," + (int)y + ")   (" + (int)x3 + "," + (int)y3);

                retaInt = new RetaGr((int)getP3().getX(),(int)getP3().getY(),(int)x3,(int)y3, getCorFlor(), getNomeFlor(),getEspFlor());
                retaInt.verificarReta(g);
                //System.out.println("RETAS DO TRIANG DESENHADO: (" + (int)getP3().getX() + "," + (int)getP3().getY() + ")   (" + (int)x3 + "," + (int)y3);

                System.out.println("Tri Interno: (" + (int)getP3().getX() + "," + (int)getP3().getY() + ")   (" + (int)x + "," + (int)y + ")   (" + (int)x3 + "," + (int)y3 + ")");
                
                
                
                // INTERMEDIARIOS
                RetaGr retaMeio;
                
                retaMeio = new RetaGr((int)xProxExt, (int)yProxExt, (int)xAntExt, (int)yAntExt, getCorFlor(),getNomeFlor(),getEspFlor());
                retaMeio.verificarReta(g);
                
                retaMeio = new RetaGr((int)xProxExt2, (int)yProxExt2, (int)xExt, (int)yExt, getCorFlor(),getNomeFlor(),getEspFlor());
                retaMeio.verificarReta(g);
                
            }
            cont++;

            // Desenha os Circulos
            for(theta = 360; theta >= 0; theta--){
                r2 = Math.sqrt(Math.pow(xc - xAnt,2) + Math.pow(yc - yAnt,2));

                radianos = Math.toRadians(theta);
                x = xAnt + r2 * Math.cos(radianos);
                y = yAnt + r2 * Math.sin(radianos);

                // Define ponto grafico
                ponto = new PontoGr((int)x, (int)y, getCorFlor(), getEspFlor());

                // Desenha ponto grafico
                ponto.desenharPonto(g);

                // desenha nome do ponto
                g.setColor(getCorNomeFlor());
                g.drawString(getNomeFlor(), (int)getP3().getX() + getEspFlor(), (int)getP4().getY());

            }

        }
        
        // DESENHA circulo interno
        for(theta = 0; theta <= 360; theta++){
            radianos = Math.toRadians(theta);
            x = xc + r * Math.cos(radianos);
            y = yc + r * Math.sin(radianos);
            
            // Define ponto grafico
            ponto = new PontoGr((int)x, (int)y, getCorFlor(), getEspFlor());
            
            // Desenha ponto grafico
            ponto.desenharPonto(g);
            
            // desenha nome do ponto
            g.setColor(getCorNomeFlor());
            g.drawString(getNomeFlor(), (int)getP3().getX() + getEspFlor(), (int)getP3().getY());
        }    

    }
}